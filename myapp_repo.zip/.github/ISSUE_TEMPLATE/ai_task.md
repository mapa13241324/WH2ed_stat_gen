---
name: AI Task
about: Zlecenie zadania dla bota (utwórz lub zmodyfikuj funkcję)
title: "[AI] Krótki opis zadania"
labels: [ai-task]
---
## Cel
Opis zadania.
