## Co zostało zmienione
- 

## Dlaczego
- 

## Testy
- [ ] Build przeszedł
