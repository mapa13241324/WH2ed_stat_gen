using System.Windows;

namespace MyApp
{
    public partial class App : Application { }
}