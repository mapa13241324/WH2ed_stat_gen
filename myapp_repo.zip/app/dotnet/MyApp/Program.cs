using System;
using System.Windows;

namespace MyApp
{
    public partial class Program
    {
        [STAThread]
        public static void Main()
        {
            var app = new App();
            app.InitializeComponent();
            app.Run();
        }
    }
}