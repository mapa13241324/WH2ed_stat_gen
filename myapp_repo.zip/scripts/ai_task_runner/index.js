#!/usr/bin/env node
import fs from 'fs';
fs.writeFileSync('app/dotnet/MyApp/AI_TODO.cs', '// TODO from AI');